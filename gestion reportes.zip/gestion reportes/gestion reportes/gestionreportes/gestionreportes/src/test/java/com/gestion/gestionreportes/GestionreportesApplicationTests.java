package com.gestion.gestionreportes; // Nota: el paquete debe ser el mismo que GestionreportesApplication.java

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionreportesApplicationTests {

    @Test
    void contextLoads() {
    }

}