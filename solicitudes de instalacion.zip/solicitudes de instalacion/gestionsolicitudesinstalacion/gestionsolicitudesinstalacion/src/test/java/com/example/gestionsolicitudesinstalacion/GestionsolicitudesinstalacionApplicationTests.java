package com.example.gestionsolicitudesinstalacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionsolicitudesinstalacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
