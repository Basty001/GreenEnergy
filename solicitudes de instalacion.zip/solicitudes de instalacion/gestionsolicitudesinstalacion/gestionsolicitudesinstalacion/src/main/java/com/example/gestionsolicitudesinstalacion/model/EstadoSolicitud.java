package com.example.gestionsolicitudesinstalacion.model;

public enum EstadoSolicitud {
    PENDIENTE,
    EN_EVALUACION,
    APROBADA,
    EN_INSTALACION,
    FINALIZADA,
    CANCELADA 
}