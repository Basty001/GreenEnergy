package com.example.gestionsolicitudesinstalacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionsolicitudesinstalacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionsolicitudesinstalacionApplication.class, args);
	}

}
