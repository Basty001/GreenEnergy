package com.gestion.gestionreportes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionreportesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionreportesApplication.class, args);
	}

}
      