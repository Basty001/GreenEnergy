package com.example.gestionprivilegios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionprivilegiosApplicationTests {

	@Test
	void contextLoads() {
	}

}
