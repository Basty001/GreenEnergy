package com.example.gestionprivilegios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionprivilegiosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionprivilegiosApplication.class, args);
	}

}
