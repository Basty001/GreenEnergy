package com.example.Notificaciones.y.Alertas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificacionesYAlertasApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotificacionesYAlertasApplication.class, args);
	}

}
