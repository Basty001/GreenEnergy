package com.example.Notificaciones.y.Alertas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacionesYAlertasApplicationTests {

	@Test
	void contextLoads() {
	}

}
