package com.example.Gestion.de.Inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
