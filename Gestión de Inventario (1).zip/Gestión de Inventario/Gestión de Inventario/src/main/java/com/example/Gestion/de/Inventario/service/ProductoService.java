package com.example.Gestion.de.Inventario.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Gestion.de.Inventario.model.Producto;
import com.example.Gestion.de.Inventario.repository.ProductoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional


public class ProductoService {
    @Autowired

    private ProductoRepository productoRepository;

    //funcion para buscar todos los pacientes
    public List<Producto> listaProducto(){
        return productoRepository.findAll();
    }

    //funcion para buscar un paciente mediante su id
    public Producto buscarProducto(long id){
        return productoRepository.findById(id).get();
    }

    //funcion para agregar un nuevo paciente
    public Producto agregarProducto(Producto Producto){
        return productoRepository.save(Producto);

    }

    //funcion para eliminar un paciente por su id
    public void eliminarProducto(long id){
        productoRepository.deleteById(id);
    }


    public Producto actualizarStock(Long id, int cantidad) {
        Producto producto = productoRepository.findById(id).orElseThrow();
        producto.setCantidadStock(producto.getCantidadStock() + cantidad);
        return productoRepository.save(producto);
    }


    public Producto actualizarProducto(Producto productoActualizado) {
        return productoRepository.save(productoActualizado);
    }
}
