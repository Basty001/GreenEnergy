package com.example.Gestion.de.Inventario.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity //convierte la clase en una entidad JPA

@Data // crea setters, getter, to string
@AllArgsConstructor //crea consutructor con parametros
@NoArgsConstructor //crea constructor sin parametros


public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String descripcion;
    private int cantidadStock;
    private double precio;
}
