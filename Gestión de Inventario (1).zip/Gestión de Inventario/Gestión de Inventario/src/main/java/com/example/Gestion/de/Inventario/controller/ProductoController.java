package com.example.Gestion.de.Inventario.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Gestion.de.Inventario.model.Producto;
import com.example.Gestion.de.Inventario.service.ProductoService;


@RestController
@RequestMapping("/api/v1/producto")
public class ProductoController {
    @Autowired

    private ProductoService productoService;

    @GetMapping
    public ResponseEntity<List<Producto>> listarProducto(){
        //variable para almacenar el resultado del select
        List<Producto> producto = productoService.listaProducto();
        //preguntar si vienen registros o no
        if(producto.isEmpty()){
            //si esta vacia retorno codigo 204
            return ResponseEntity.noContent().build();
        }
        //si no esta vacia retorno codigo 200 cn la lista
        return ResponseEntity.ok(producto);
    }

    @PostMapping
    public ResponseEntity<Producto> saveProducto(@RequestBody Producto pro){
        //variable para almacenar el retorno del servicio
        Producto producto2 = productoService.agregarProducto(pro);
        return ResponseEntity.status(HttpStatus.CREATED).body(producto2);
    }

    @PutMapping
    public Producto actualizarProducto(@RequestBody Producto productoActualizado) {
        return productoService.actualizarProducto(productoActualizado);
    }


    @DeleteMapping("/{id}")
    public String eliminarProducto(@PathVariable Long id) {
        productoService.eliminarProducto(id);
        return "Producto" + id + "borrado";
    }

}
